package GraphAlgorithm;

public interface Heuristic {
		public float estimateWeight(int current);
}
