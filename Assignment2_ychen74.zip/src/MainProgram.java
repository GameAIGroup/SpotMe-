/*
 * License information:
 * 
 * ===================
 * Project Information
 * ===================
 * Name: CSC 584, Assignments
 * 
 * Topic:
 * This pr1ogram is created for 2016 spring, CSC 584 Assignments
 * Assignment 1: test various movement algorithms.
 * Assignment 2: test path finding and path following.
 *  
 * ==================
 * Author information
 * ==================
 * Name: Yi-Chun Chen
 * UnityID: ychen74
 * Student ID:200110436
 * 
 * ==========
 * References
 * ==========
 * 1. textbook.
 * 
 */


/*
 * Program Descriptions
 * =================
 * Coding Convention
 * =================
 * - global: Pascal casing.
 * - local: Camel casing
 * - function input: Pascal casing
 * - function output: Pascal casing
 * - function name: Camel casing
 * - class name: Pascal casing  
 *
 *=====
 *Logic
 *=====
 *- Each basic behavior will be called as function, and return new acceleration or velocity
 *
 *
 */

/*
 * ==============
 * Import Library
 * ==============
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import BasicBehavior.*;
import BasicStructures.*;
import DrawData.*;
import GraphAlgorithm.*;
import GraphData.*;
import MovementStructures.*;
//import OldFile.*;
import Variables.GlobalSetting;
import processing.core.*;

/*
 * =============
 * Class Declare
 * =============
 */
public class MainProgram extends PApplet{
/*
 * ============================
 * Variables for Shared Setting
 * ============================
 */
	private int windowWidth;
	private int windowHeight;
	private SystemParameter Sys;
	private KinematicOperations OperK;
	private TimeControler decisionTimer;
	private TimeControler breadTimer;

	
	
	//Setting for environment
	private ColorVectorRGB backgroundColor;
	private CharacterDrop character;
	
	//private Seek_Steering_New Seek;
	
	private Seek Seek;
	
	private Vector2 originalPoint;
	private Vector2 initialTarget;
	
	//Seek function
	//private KinematicStructure tempK;
	//private KinematicBehavior tempKB;
	//private Seek_Steering tempS;
	private float maxVelocity;
	
	private ResultChange tempResult;
	
	private PImage img;
	private MapGenerator mapCreate;
	private boolean showObstacleNode;
	
	private GraphGenerator GraphGenerator;
	private GraphData G;
	
	private Dijkstra D;
	private AStar A1;
	private AStar A2;
	private AStar A3;
	
	private List<Node> currentNodeList;
	private List<Edge> currentEdgeList;
	
	private TimeControler diffTime;
	
/*
 * ====================
 * Variables for Others
 * ====================
 */

/*
 * (non-Javadoc)
 * @see processing.core.PApplet#settings()
 * ===========================
 * Setting and Initializations
 * ===========================
 */
	
	boolean isSeeking = false;
	List<Integer> currentTargetQueue;
	int targetIndex;
	int closestIndex;
	
	public static GlobalSetting globalS;
	
	public void settings(){
		
		globalS = new GlobalSetting();
		currentTargetQueue = new ArrayList<Integer>();
		
		windowWidth = 800;
		windowHeight = 600;
		
		img = loadImage("gold-garrison.png");
		//img = loadImage("Girl.png");
		
		size(windowWidth, windowHeight);
		// input this operations for each kinematics
		
		
		Sys = new SystemParameter(5, 5*0.1f);

		OperK = new KinematicOperations(this, Sys);
		originalPoint = new Vector2(0, 0);
		decisionTimer = new TimeControler();
		decisionTimer.initialTimer();
		breadTimer = new TimeControler();
		breadTimer.initialTimer();

		diffTime = new TimeControler();
		
		
		backgroundColor = new ColorVectorRGB(255, 255, 255);
		
		
		Vector2 currentShapePosition = new Vector2(windowWidth/2 , windowHeight/2);
		Vector2 initialVelocity = new Vector2(0, 0);
		Vector2 initialAccel = new Vector2(0, 0);
		ColorVectorRGB tempColor = new ColorVectorRGB(23, 228, 119);

		
		maxVelocity = 5;
		
		character = new CharacterDrop(
			this,
			20,
			20,
			originalPoint,
			currentShapePosition,
			0,
			initialVelocity,
			0,
			OperK,				
			initialAccel,
			0,
			tempColor,
			backgroundColor,
			GlobalSetting.numberOfBread
		);
/*		
		Seek = new Seek_Steering_New(
				20.0f,
				100.0f,
				0.1f,
				currentShapePosition,
				1,
				currentShapePosition,
				initialVelocity,
				0,
				0,
				initialAccel,
				0,
				OperK,
				Sys.getMaxV(),
				Sys.getMaxV()*0.1f,
				this
				
		);
*/
		Seek = new Seek(
				5.0f,
				100.0f,
				0.1f,
				currentShapePosition,
				1,
				currentShapePosition,
				initialVelocity,
				0,
				0,
				initialAccel,
				0,
				OperK,
				Sys.getMaxV(),
				Sys.getMaxV()*0.1f,
				this
				
		);
		
		//Seek
/*		
		tempK = new KinematicStructure(
				currentShapePosition,
				0,
				initialVelocity,
				0
		);
		tempKB = new KinematicBehavior(this, maxVelocity, maxVelocity, 1 ,20);
		tempS =  new Seek_Steering(5.0f, 100.0f, 0.1f, currentShapePosition, maxVelocity, maxVelocity*0.05f , 1, 20,tempK, 20, this);		
*/		
		initialTarget = currentShapePosition;
		tempResult = new ResultChange(
				character.getPosition().getX(),
				character.getPosition().getY(),
				character.getK().getOrientation(),
				character.getK().getVelocity().getX(),
				character.getK().getVelocity().getY(),
				character.getK().getRotation(),
				OperK,
				character.getS().getLinearAccel().getX(),
				character.getS().getLinearAccel().getY(),
				character.getS().getAngularAccel()
			);
		
			
			//This part order cannot be changed
		
			mapCreate = new MapGenerator(5, 7, "test.txt");
			//mapCreate.createRandomGraph("random.txt");

			mapCreate.drawDot2(GlobalSetting.generatedNode, windowWidth, windowHeight);
			
			mapCreate.readObstacles(this);
			mapCreate.isObstacle = true;
			
			GraphGenerator = new GraphGenerator(mapCreate, OperK, this);
			GraphGenerator.createEdge();
			
			G = new GraphData(GraphGenerator.nodeList, GraphGenerator.edgeList, this);
			
			currentNodeList = new ArrayList<Node>();
			currentNodeList = G.nodeList;
			
			currentEdgeList = new ArrayList<Edge>();
			currentEdgeList = G.edgeList;
			System.out.println("");

			int loopCount = 0;
			float totalWeight =0;
			D = new Dijkstra(G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart);
			//for(int i =0; i <25; i++){
			diffTime.initialTimer();
			while(D.openList.size()>0){
				loopCount++;
				D.computDijkstra(G.nodeList, G.edgeList);
				//System.out.println("-----------");
			}
			System.out.println("Used time: " + diffTime.getTimeDiffer());
			if(D.isFind == false){
				System.out.println("Didn't find!!");
			}
			else{
				System.out.print("Dijkstra Path: ");
				totalWeight = 0;
				for(int i = 0 ;i < D.result.size(); i++){
					if(i>0){
						totalWeight = totalWeight + OperK.getDisBy2Points(currentNodeList.get(D.result.get(i-1)).coordinate, currentNodeList.get(D.result.get(i)).coordinate);
					}
					System.out.print(" " + D.result.get(i)+" ");
				}
				System.out.println("\r\n Total Weight" + totalWeight+" Total Fill of Dijkstra = " +(D.openList.size() +D.closeList.size())+", Search "+loopCount +" Nodes");
		}
			
			System.out.println("");

			H1 h1 = new H1(G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart, OperK);

			
			A1 = new AStar(h1, G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart);
			
			loopCount = 0;
			diffTime.initialTimer();
			while(A1.openList.size()>0){
				loopCount++;
				A1.computeAStar(G.nodeList, G.edgeList);
				//System.out.println("-----------");
			}
			System.out.println("Used time: " + diffTime.getTimeDiffer());
			if(A1.isFind == false){
				System.out.println("Didn't find!!");
			}
			else{
				System.out.print("\r\nAStar with H1 Path: ");
				totalWeight = 0;
				for(int i = 0 ;i < A1.result.size(); i++){
					if(i>0){
						totalWeight = totalWeight + OperK.getDisBy2Points(currentNodeList.get(A1.result.get(i-1)).coordinate, currentNodeList.get(A1.result.get(i)).coordinate);
					}
					System.out.print(" " + A1.result.get(i)+" ");
				}
				System.out.println("\r\n Total Weight" + totalWeight+" Total Fill of H1 = " +(A1.openList.size() +A1.closeList.size())+", Search "+loopCount +" Nodes");

			}

			
			System.out.println("");

			H2 h2 = new H2(G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart, OperK);
			A2 = new AStar(h2, G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart);
			loopCount =0;
			diffTime.initialTimer();
			while(A2.openList.size()>0){
				loopCount++;
				A2.computeAStar(G.nodeList, G.edgeList);
				//System.out.println("-----------");
			}
			System.out.println("Used time: " + diffTime.getTimeDiffer());
			
			if(A2.isFind == false){
				System.out.println("Didn't find!!");
			}
			else{

				System.out.print("\r\nAStar with H2 Path: ");
				totalWeight = 0;
				for(int i = 0 ;i < A2.result.size(); i++){
					if(i>0){
						totalWeight = totalWeight + OperK.getDisBy2Points(currentNodeList.get(A2.result.get(i-1)).coordinate, currentNodeList.get(A2.result.get(i)).coordinate);
					}
					System.out.print(" " + A2.result.get(i)+" ");
				}
				System.out.println("\r\n Total Weight" + totalWeight+" Total Fill of H2 = " +(A2.openList.size() +A2.closeList.size())+", Search "+loopCount +" Nodes");

			}
			
			System.out.println("");
			H3 h3 = new H3(G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart, OperK);
			A3 = new AStar(h3, G.nodeList, G.edgeList, GlobalSetting.testGoal, GlobalSetting.testStart);
			loopCount = 0;
			diffTime.initialTimer();
			while(A3.openList.size()>0){
				loopCount++;
				A3.computeAStar(G.nodeList, G.edgeList);
				//System.out.println("-----------");
			}
			System.out.println("Used time: " + diffTime.getTimeDiffer());
			if(A3.isFind == false){
				System.out.println("Didn't find!!");
			}
			else{
				System.out.print("\r\nAStar with H3 Path: ");
				totalWeight = 0;
				for(int i = 0 ;i < A3.result.size(); i++){
					if(i>0){
						totalWeight = totalWeight + OperK.getDisBy2Points(currentNodeList.get(A3.result.get(i-1)).coordinate, currentNodeList.get(A3.result.get(i)).coordinate);
					}
					System.out.print(" " + A3.result.get(i)+" ");
				}
				System.out.println("\r\n Total Weight" + totalWeight+" Total Fill of H3 = " +(A3.openList.size() +A3.closeList.size())+", Search "+loopCount +" Nodes");

			}		
			
	
			System.out.println("");
	}
/*
 * 	(non-Javadoc)
 * @see processing.core.PApplet#draw()
 * =========
 * Draw Loop
 * =========
 */

	
	public void draw(){
		background(backgroundColor.getR(), backgroundColor.getG(), backgroundColor.getB());
		
		image(img,0,0);
		
		character.updatePosition(character.getK().getPosition());
		character.updateOrientation(character.getK().getOrientation());		
		//tempS.updateTargetPosition(initialTarget);
		
		if(isSeeking == false){
			if(mousePressed){
				isSeeking = true;
				initialTarget = new Vector2(mouseX, mouseY);
				
				//call path finding
				targetIndex = findClose(currentNodeList, initialTarget);
				closestIndex = findClose(currentNodeList, character.getK().getPosition());
				
				//System.out.println(targetIndex+ ", " + closestIndex);
				if(GlobalSetting.HeuristicMode == 0){
				H1 h1 = new H1(currentNodeList, currentEdgeList, targetIndex, closestIndex, OperK);
				
				A1 = new AStar(h1, currentNodeList, currentEdgeList, targetIndex, closestIndex);

				while(A1.openList.size()>0){
					A1.computeAStar(G.nodeList, G.edgeList);
					//System.out.println("-----------");
				}
				if(A1.isFind == false){
					System.out.println("Didn't find!!");
				}
				else{
					System.out.print("\r\nAStar with H1 Path: ");
					for(int i = 0 ;i < A1.result.size(); i++){
						System.out.print(" " + A1.result.get(i)+" ");
					}
				}
				currentTargetQueue.clear();
				currentTargetQueue.addAll(A1.result);
				}
				else if(GlobalSetting.HeuristicMode == 1){
					H2 h2 = new H2(G.nodeList, G.edgeList, targetIndex, closestIndex, OperK);
					A2 = new AStar(h2, G.nodeList, G.edgeList, targetIndex, closestIndex);

					while(A2.openList.size()>0){
						A2.computeAStar(G.nodeList, G.edgeList);
						//System.out.println("-----------");
					}
					if(A2.isFind == false){
						System.out.println("Didn't find!!");
					}
					else{
						System.out.print("\r\nAStar with H2 Path: ");
						for(int i = 0 ;i < A2.result.size(); i++){
							System.out.print(" " + A2.result.get(i)+" ");
						}
					}
					System.out.println("");

					currentTargetQueue.clear();
					currentTargetQueue.addAll(A2.result);
				}
				else if(GlobalSetting.HeuristicMode == 2){
					H3 h3 = new H3(G.nodeList, G.edgeList, targetIndex, closestIndex, OperK);
					A3 = new AStar(h3, G.nodeList, G.edgeList, targetIndex, closestIndex);

					while(A3.openList.size()>0){
						A3.computeAStar(G.nodeList, G.edgeList);
						//System.out.println("-----------");
					}
					if(A3.isFind == false){
						System.out.println("Didn't find!!");
					}
					else{
						System.out.print("\r\nAStar with H3 Path: ");
						for(int i = 0 ;i < A3.result.size(); i++){
							System.out.print(" " + A3.result.get(i)+" ");
						}
					}
					System.out.println("");

					currentTargetQueue.clear();
					currentTargetQueue.addAll(A3.result);
				}
				else{
					D = new Dijkstra(G.nodeList, G.edgeList,targetIndex, closestIndex);
					//for(int i =0; i <25; i++){
					while(D.openList.size()>0){
						D.computDijkstra(G.nodeList, G.edgeList);
						//System.out.println("-----------");
					}
					if(D.isFind == false){
						System.out.println("Didn't find!!");
					}
					else{
						System.out.print("Dijkstra Path: ");
						for(int i = 0 ;i < D.result.size(); i++){
							System.out.print(" " + D.result.get(i)+" ");
						}
					}
					System.out.println("");
					currentTargetQueue.clear();
					currentTargetQueue.addAll(D.result);
					
				}

				
				//Gathering dots
				//stroke(0);
				//ellipse( mouseX, mouseY, 5, 5 );
				//text( "x: " + mouseX + " y: " + mouseY, mouseX + 2, mouseY );	
				//mapCreate.drawDot(new Vector2(mouseX, mouseY));
	
			}
		}
		
		//make decisions in 0.02 sec frequency
		if(decisionTimer.checkTimeSlot(20)){
			//make one decision

			//character.updatePosition(character.getPosition().getX()+10.0f, character.getPosition().getY()+2.0f);

			if(isSeeking == true){
				if(currentTargetQueue.size()>0){
					//if(findClose(currentNodeList,character.getK().getPosition())!=currentTargetQueue.get(0)){
					if(OperK.getDisBy2Points(currentNodeList.get(currentTargetQueue.get(0)).coordinate, character.getK().getPosition())>5){
						//System.out.println("Current Target = " + currentTargetQueue.get(0));
						initialTarget = currentNodeList.get(currentTargetQueue.get(0)).coordinate;
					}
					else{
						currentTargetQueue.remove(0);
					}

					tempResult = Seek.computeSeek(initialTarget);
			
					character.setK(tempResult.getK());
					character.setS(tempResult.getS());
				}
				else{
					isSeeking = false;
					
				}
				
			}

			//System.out.println(character.getK().getPosition().getX() +", " +character.getK().getPosition().getY());
		}

		//record
		if(breadTimer.checkTimeSlot(200)){
			character.updateBreadQueue(character.getPosition(), character.getOrientation());
		}
		//display		

		//GraphGenerator.edgeDraw();
		G.edgeDraw();
		mapCreate.obstacleDisplay(this);
		character.display();

	}
/*
 * ==========================
 * Start Point of the Program
 * ==========================	
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" This is new program.");
		PApplet.main(new String[] { "--present", "MainProgram" });
	}
	public int findClose(List<Node> NodeList, Vector2 Point){
		int resultIndex = 0;
		float minDistance = 0;
		float tempDistance = 0;
		
		for(int i = 0; i< NodeList.size();i++){
			tempDistance = OperK.getDisBy2Points(NodeList.get(i).coordinate, Point);

			if(i == 0){
				minDistance = tempDistance;
				resultIndex = i;
			}
			if(tempDistance < minDistance){
				minDistance = tempDistance;
				resultIndex = i;
			}
		}
		return resultIndex;
	}
}
