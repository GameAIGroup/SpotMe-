package GraphData;

import BasicStructures.*;

public class IndexWeightPair {
	public int index;
	public float weight;
	
	public IndexWeightPair(int Index, float Weight){
		this.index = Index;
		this.weight = Weight;
	}
}
